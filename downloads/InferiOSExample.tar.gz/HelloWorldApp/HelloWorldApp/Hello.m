//
//  Hello.m
//  HelloWorldApp
//
//  Created by Dulma Rodriguez on 20/05/2015.
//  Copyright (c) 2015 Dulma Rodriguez. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Hello.h"

@implementation Hello

-(Hello*) return_hello {
    return [Hello new];
}


@end