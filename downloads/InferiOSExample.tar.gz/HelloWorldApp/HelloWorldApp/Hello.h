//
//  Hello.h
//  HelloWorldApp
//
//  Created by Dulma Rodriguez on 20/05/2015.
//  Copyright (c) 2015 Dulma Rodriguez. All rights reserved.
//

#import <Foundation/NSObject.h>

@interface Hello : NSObject {
    @public int x;
    @public Hello* hello;
}

-(Hello*) return_hello;

@end