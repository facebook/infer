//
//  AppDelegate.h
//  HelloWorldApp
//
//  Created by Dulma Rodriguez on 20/05/2015.
//  Copyright (c) 2015 Dulma Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

